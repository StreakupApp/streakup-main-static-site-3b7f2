In May 2024, I was an 18-year-old student who kept quitting hobbies after a week. 
Frustrated with existing habit trackers, which felt tedious, unintuitive, and more analytical than motivating, I decided to build my own.
I taught myself programming and developed StreakUp simultaneously, spending thousands of hours crafting an app that feels premium, rewarding, and genuinely useful. StreakUp launched on October 18, 2025, and I continue to develop it solo.

