# StreakUp — Press Kit

## About
StreakUp is a habit tracking app for only Android yet focused on premium design, 
rewarding feedback, and generous free tier. Built solo with Flutter.

**Platform:** iOS & Android  
**Price:** Free with optional Premium
**Launch date:** October 18, 2025
**Developer:** [MKAAPPS]
**Contact:** team@streakup.com
**Website:** https://streakup.pro

## What's in this kit
- `origin_story.md` — founder background
- `app_descriptions.md` — store descriptions in 8 languages
- `icon/` — app icons in 3 sizes
- `app_store_screenshots/` — polished store screenshots
- `promotional_photos/` — promotional assets
- `raw_screenshots/` — unframed in-app screenshots

## Logo & Asset Usage
You may use the icon and screenshots for editorial coverage of StreakUp.
Please do not alter the logo or use assets for commercial purposes.
Also, I'd love to know if StreakUp appears in your article, feel free to reach out at team@streakup.pro!
